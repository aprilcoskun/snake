# Snake Game
Example Snake Game using electron & p5.js

##### Install dependencies and run the app
```
npm install && npm start
```
